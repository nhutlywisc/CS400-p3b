/**
 * Checked exception thrown when a non existent key is specified for get.
 */
@SuppressWarnings("serial")
public class KeyNotFoundException extends Exception {

}
